## Green Example Theme ##
- Theme Author: CatoTheYounger 
- Music Source: https://www.youtube.com/watch?v=tZbtmrfDsRQ
- Background Source: PS3 XMB Green, Dima353

![2022-09-08-222745](https://user-images.githubusercontent.com/82458228/189245530-85149766-bfe4-41e5-88b1-6bac22d04e69.png)
