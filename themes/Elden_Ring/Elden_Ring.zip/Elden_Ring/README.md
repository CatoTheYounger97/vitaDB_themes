## Elden Ring Theme ##
- Theme Author: Brandonheat8 
- Music Source: https://youtu.be/goS6qfj8Y8Y
- Background Source: Elden Ring, Brandonheat8

![2022-09-10-150641](https://user-images.githubusercontent.com/82458228/189487069-858bb13b-7fb8-4ed7-a8f4-c09fc73f7556.png)
