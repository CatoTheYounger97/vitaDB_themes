## Bloodborne Theme ##
- Theme Author: Brandonheat8 
- Music Source: https://youtu.be/1EISe-WdZYE
- Background Source: Brandonheat8

![image](https://user-images.githubusercontent.com/82458228/189461133-27d82635-d5bc-4440-872a-5ba3965a4d8a.png)
