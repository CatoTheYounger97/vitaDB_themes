## Default VitaDB Downloader Theme ##
- Theme Author: Rinnegatamante 
- Music Source: https://www.youtube.com/watch?v=tZbtmrfDsRQ
- Background Source: PS3 XMB Blue

![2022-09-09-005357](https://user-images.githubusercontent.com/82458228/189245269-30d13aa5-6f1f-43e3-bbc0-f0eec959213c.png)
