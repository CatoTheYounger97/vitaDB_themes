## Purple Example Theme ##
- Theme Author: CatoTheYounger 
- Music Source: https://www.youtube.com/watch?v=tZbtmrfDsRQ
- Background Source: PS3 XMB Violet, Dima353

![2022-09-08-224121](https://user-images.githubusercontent.com/82458228/189245860-b7aa1717-0a25-4a97-80d9-b3e4de6d29c8.png)
