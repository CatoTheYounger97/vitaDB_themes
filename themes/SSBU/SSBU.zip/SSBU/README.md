## Elden Ring Theme ##
- Theme Author: Brandonheat8 
- Music Source: https://youtu.be/UAASQ2qmNho
- Background Source: SSBU, Brandonheat8

![image](https://user-images.githubusercontent.com/82458228/189502798-c0fb4b76-ebb8-4925-8582-89b9b77d089a.png)
